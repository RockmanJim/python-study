def test1():
	print("send msg")