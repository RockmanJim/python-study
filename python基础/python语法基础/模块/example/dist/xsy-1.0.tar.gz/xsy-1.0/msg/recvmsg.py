def test2():
	print("recv msg")