from distutils.core import setup

setup(name="xsy", version="1.0", description="xsy's module", author="RockmanJim", py_modules=["msg.sendmsg", "msg.recvmsg"])
